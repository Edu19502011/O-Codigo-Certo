package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/api/types/container"
	"github.com/docker/docker/client"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
)

type CodeExecutionRequest struct {
	Code     string `json:"code" binding:"required"`
	Language string `json:"language" binding:"required"`
	TestCases []string `json:"test_cases"`
}

type CodeExecutionResponse struct {
	Output    string   `json:"output"`
	Error     string   `json:"error,omitempty"`
	ExitCode  int      `json:"exit_code"`
	ExecutionTime float64 `json:"execution_time"`
	TestResults []TestResult `json:"test_results,omitempty"`
}

type TestResult struct {
	Name   string `json:"name"`
	Passed bool   `json:"passed"`
	Output string `json:"output,omitempty"`
}

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

type CodeExecutionService struct {
	dockerClient *client.Client
}

func NewCodeExecutionService() (*CodeExecutionService, error) {
	cli, err := client.NewClientWithOpts(client.FromEnv, client.WithAPIVersionNegotiation())
	if err != nil {
		return nil, fmt.Errorf("failed to create docker client: %w", err)
	}
	
	return &CodeExecutionService{
		dockerClient: cli,
	}, nil
}

func (s *CodeExecutionService) ExecuteCode(ctx context.Context, req CodeExecutionRequest) (*CodeExecutionResponse, error) {
	startTime := time.Now()
	
	var imageName string
	var cmd []string
	
	switch req.Language {
	case "javascript", "js":
		imageName = "node:18-alpine"
		cmd = []string{"node", "-e", req.Code}
	case "python", "py":
		imageName = "python:3.11-alpine"
		cmd = []string{"python", "-c", req.Code}
	case "go":
		imageName = "golang:1.21-alpine"
		cmd = []string{"go", "run", "-"}
	default:
		return nil, fmt.Errorf("unsupported language: %s", req.Language)
	}
	
	resp, err := s.dockerClient.ContainerCreate(ctx, &container.Config{
		Image: imageName,
		Cmd:   cmd,
		Tty:   false,
		NetworkDisabled: true,
	}, &container.HostConfig{
		Resources: container.Resources{
			Memory:   128 * 1024 * 1024, // 128MB
			NanoCPUs: 1000000000,         // 1 CPU
		},
		AutoRemove: true,
	}, nil, nil, "")
	
	if err != nil {
		return nil, fmt.Errorf("failed to create container: %w", err)
	}
	
	defer s.dockerClient.ContainerRemove(ctx, resp.ID, types.ContainerRemoveOptions{
		Force: true,
	})
	
	if err := s.dockerClient.ContainerStart(ctx, resp.ID, types.ContainerStartOptions{}); err != nil {
		return nil, fmt.Errorf("failed to start container: %w", err)
	}
	
	timeoutCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	
	statusCh, errCh := s.dockerClient.ContainerWait(timeoutCtx, resp.ID, container.WaitConditionNotRunning)
	select {
	case err := <-errCh:
		if err != nil {
			return nil, fmt.Errorf("error waiting for container: %w", err)
		}
	case <-statusCh:
	}
	
	out, err := s.dockerClient.ContainerLogs(ctx, resp.ID, types.ContainerLogsOptions{
		ShowStdout: true,
		ShowStderr: true,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to get container logs: %w", err)
	}
	defer out.Close()
	
	outputBytes, err := io.ReadAll(out)
	if err != nil {
		return nil, fmt.Errorf("failed to read output: %w", err)
	}
	
	executionTime := time.Since(startTime).Seconds()
	
	return &CodeExecutionResponse{
		Output:        string(outputBytes),
		ExitCode:      0,
		ExecutionTime: executionTime,
	}, nil
}

func setupRouter(service *CodeExecutionService) *gin.Engine {
	r := gin.Default()
	
	r.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, DELETE")
		
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		
		c.Next()
	})
	
	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"status": "healthy",
			"service": "code-execution",
		})
	})
	
	r.POST("/api/execute", func(c *gin.Context) {
		var req CodeExecutionRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		
		result, err := service.ExecuteCode(c.Request.Context(), req)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}
		
		c.JSON(http.StatusOK, result)
	})
	
	r.GET("/ws/execute", func(c *gin.Context) {
		conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
		if err != nil {
			log.Printf("Failed to upgrade connection: %v", err)
			return
		}
		defer conn.Close()
		
		for {
			var req CodeExecutionRequest
			err := conn.ReadJSON(&req)
			if err != nil {
				if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
					log.Printf("WebSocket error: %v", err)
				}
				break
			}
			
			conn.WriteJSON(map[string]string{
				"status": "executing",
				"message": "Criando container Docker...",
			})
			
			result, err := service.ExecuteCode(context.Background(), req)
			if err != nil {
				conn.WriteJSON(map[string]string{
					"status": "error",
					"error": err.Error(),
				})
				continue
			}
			
			responseData, _ := json.Marshal(result)
			conn.WriteJSON(map[string]interface{}{
				"status": "completed",
				"data": json.RawMessage(responseData),
			})
		}
	})
	
	return r
}

func main() {
	service, err := NewCodeExecutionService()
	if err != nil {
		log.Fatal("Failed to initialize code execution service:", err)
	}
	
	router := setupRouter(service)
	
	log.Println("🚀 Code Execution Service starting on :8080")
	log.Println("📦 Docker containers will be created for code execution")
	log.Println("🔒 Network isolated for security")
	
	if err := router.Run(":8080"); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}
