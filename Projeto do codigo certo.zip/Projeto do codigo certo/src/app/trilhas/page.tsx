"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Bot, Brain, Lock, CheckCircle2, Clock, ArrowRight, ZoomIn, ZoomOut, RotateCcw } from "lucide-react"
import { motion } from "framer-motion"

type SkillStatus = "completed" | "current" | "locked"

interface SkillNode {
  id: string
  title: string
  icon: string
  status: SkillStatus
  progress?: number
  modules?: Array<{ title: string; completed: boolean }>
}

const skillTree: SkillNode[] = [
  { id: "fundamentos", title: "Fundamentos JS", icon: "📚", status: "completed" },
  { id: "funcoes", title: "Funções Avançadas", icon: "⚙️", status: "completed" },
  { id: "objetos", title: "Objetos & Arrays", icon: "🎯", status: "completed" },
  {
    id: "promises",
    title: "Promises",
    icon: "🔄",
    status: "current",
    progress: 70,
    modules: [
      { title: "Introdução a Promises", completed: true },
      { title: "Promise Chaining", completed: true },
      { title: "Error Handling", completed: false },
      { title: "Promise.all e Promise.race", completed: false },
    ],
  },
  { id: "async", title: "Async/Await", icon: "⚡", status: "locked" },
  { id: "closures", title: "Closures", icon: "🎁", status: "locked" },
  { id: "design-patterns", title: "Design Patterns", icon: "🏗️", status: "locked" },
  { id: "performance", title: "Performance", icon: "🚀", status: "locked" },
  { id: "master", title: "JavaScript Master", icon: "👑", status: "locked" },
]

export default function TrilhasPage() {
  const [selectedSkill, setSelectedSkill] = useState(skillTree.find((s) => s.status === "current"))
  const [zoom, setZoom] = useState(1)

  const getStatusIcon = (status: SkillStatus) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "current":
        return <Clock className="h-4 w-4 text-primary animate-pulse" />
      case "locked":
        return <Lock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: SkillStatus) => {
    switch (status) {
      case "completed":
        return "border-green-500 bg-green-500/10"
      case "current":
        return "border-primary bg-primary/10 ring-2 ring-primary/20"
      case "locked":
        return "border-muted bg-muted/5"
    }
  }

  return (
    <div className="container py-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-4xl font-bold flex items-center gap-3">
          🗺️ Sua Trilha de Aprendizado Personalizada
        </h1>
        <p className="text-muted-foreground text-lg">
          Árvore de habilidades adaptativa gerada por IA
        </p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-[350px_1fr]">
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="card-gradient border-primary/20">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                    <Bot className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Tutor IA</CardTitle>
                    <CardDescription className="text-xs">Sempre disponível</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm">
                  Olá! Estou aqui para guiar sua jornada. Precisa de ajuda?
                </p>
                <Button className="w-full" size="sm">
                  <Brain className="mr-2 h-4 w-4" />
                  Conversar com IA
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Seu Progresso</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Nível Atual</span>
                  <Badge>Intermediário</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Habilidades</span>
                  <strong className="text-sm">23/50</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">XP Total</span>
                  <strong className="text-sm">4,850</strong>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-orange-500/20 bg-gradient-to-br from-orange-500/5 to-yellow-500/5">
              <CardHeader>
                <CardTitle className="text-base">Próxima Habilidade</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-3">
                  <span className="text-3xl">⚡</span>
                  <div>
                    <p className="font-semibold text-sm">Async/Await Patterns</p>
                    <p className="text-xs text-muted-foreground">Estimativa: 2-3 horas</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Árvore de Habilidades</CardTitle>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setZoom((z) => Math.min(z + 0.1, 1.5))}
                    >
                      <ZoomIn className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setZoom((z) => Math.max(z - 0.1, 0.5))}
                    >
                      <ZoomOut className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setZoom(1)}>
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div
                  className="relative p-8 min-h-[500px] overflow-auto"
                  style={{ transform: `scale(${zoom})`, transformOrigin: "top left" }}
                >
                  <div className="flex flex-col items-center gap-6">
                    {skillTree.map((skill, index) => (
                      <motion.div
                        key={skill.id}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                        className="w-full max-w-sm"
                      >
                        <Card
                          className={`cursor-pointer transition-all hover:shadow-lg ${getStatusColor(skill.status)} ${
                            selectedSkill?.id === skill.id ? "ring-2 ring-primary" : ""
                          }`}
                          onClick={() => setSelectedSkill(skill)}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-center gap-4">
                              <span className="text-4xl">{skill.icon}</span>
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold">{skill.title}</h4>
                                  {getStatusIcon(skill.status)}
                                </div>
                                {skill.progress !== undefined && (
                                  <div className="mt-2">
                                    <Progress value={skill.progress} className="h-2" />
                                    <p className="text-xs text-muted-foreground mt-1">
                                      {skill.progress}% completo
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {selectedSkill && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              key={selectedSkill.id}
            >
              <Card className="border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{selectedSkill.icon}</span>
                    <div>
                      <CardTitle>{selectedSkill.title}</CardTitle>
                      <CardDescription>
                        {selectedSkill.status === "completed" && "✓ Concluído"}
                        {selectedSkill.status === "current" && "⏳ Em Progresso"}
                        {selectedSkill.status === "locked" && "🔒 Bloqueado"}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedSkill.modules && (
                    <div>
                      <h4 className="font-semibold mb-3">Módulos</h4>
                      <div className="space-y-2">
                        {selectedSkill.modules.map((module, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-3 p-2 rounded-lg border"
                          >
                            <div
                              className={`w-6 h-6 rounded-full flex items-center justify-center ${
                                module.completed
                                  ? "bg-green-500 text-white"
                                  : "bg-muted text-muted-foreground"
                              }`}
                            >
                              {module.completed ? "✓" : i + 1}
                            </div>
                            <span className="text-sm">{module.title}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedSkill.status !== "locked" && (
                    <Button className="w-full" size="lg">
                      {selectedSkill.status === "current" ? "Continuar Módulo" : "Revisar"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  )}

                  {selectedSkill.status === "locked" && (
                    <div className="text-center py-4">
                      <Lock className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        Complete as habilidades anteriores para desbloquear
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}
