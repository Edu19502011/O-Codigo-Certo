"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Briefcase,
  MapPin,
  DollarSign,
  Clock,
  TrendingUp,
  Star,
  Building2,
  Sparkles,
  ArrowRight,
} from "lucide-react"
import { motion } from "framer-motion"

const jobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp",
    location: "Remote",
    salary: "R$ 12.000 - 18.000",
    type: "Full-time",
    match: 95,
    skills: ["React", "TypeScript", "Next.js"],
    posted: "2 dias atrás",
  },
  {
    id: 2,
    title: "Full Stack Engineer",
    company: "StartupXYZ",
    location: "São Paulo, SP",
    salary: "R$ 10.000 - 15.000",
    type: "Full-time",
    match: 88,
    skills: ["Node.js", "React", "PostgreSQL"],
    posted: "5 dias atrás",
  },
  {
    id: 3,
    title: "JavaScript Developer",
    company: "Digital Solutions",
    location: "Remoto",
    salary: "R$ 8.000 - 12.000",
    type: "Full-time",
    match: 82,
    skills: ["JavaScript", "Vue.js", "MongoDB"],
    posted: "1 semana atrás",
  },
]

export default function CarreirasPage() {
  return (
    <div className="container py-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-4xl font-bold flex items-center gap-3">
          <Briefcase className="h-10 w-10" />
          Carreiras 2.0
        </h1>
        <p className="text-muted-foreground text-lg">
          Matchmaking inteligente conectando talentos a oportunidades
        </p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="card-gradient border-primary/20">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <CardTitle>Vagas Recomendadas pela IA</CardTitle>
                </div>
                <CardDescription>
                  Baseado nas suas habilidades e conquistas na plataforma
                </CardDescription>
              </CardHeader>
            </Card>
          </motion.div>

          <div className="space-y-4">
            {jobs.map((job, index) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <Card className="hover-lift cursor-pointer border-l-4 border-l-transparent hover:border-l-primary transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg mb-1">{job.title}</h3>
                          <p className="text-muted-foreground">{job.company}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 mb-2">
                          <Sparkles className="h-3 w-3 mr-1" />
                          {job.match}% Match
                        </Badge>
                        <p className="text-xs text-muted-foreground">{job.posted}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span>{job.salary}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{job.type}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {job.skills.map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1">
                        Candidatar-se
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                      <Button variant="outline">Salvar</Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Seu Portfólio</CardTitle>
                <CardDescription>Gerado automaticamente</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-3 bg-primary/5 rounded-lg">
                  <div className="text-3xl font-bold text-primary">4.8</div>
                  <p className="text-sm text-muted-foreground">Pontuação Geral</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Habilidades Técnicas</span>
                      <span className="font-medium">92%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary" style={{ width: "92%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Projetos Completos</span>
                      <span className="font-medium">15</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500" style={{ width: "75%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Atividade na Comunidade</span>
                      <span className="font-medium">88%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500" style={{ width: "88%" }} />
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  Visualizar Portfólio Completo
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Badges Conquistadas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { emoji: "🏆", name: "Promise Master" },
                    { emoji: "⚡", name: "Speed Coder" },
                    { emoji: "🎯", name: "100 Desafios" },
                    { emoji: "👥", name: "Mentor" },
                    { emoji: "🔥", name: "30 Dias" },
                    { emoji: "💻", name: "Full Stack" },
                  ].map((badge, i) => (
                    <div
                      key={i}
                      className="flex flex-col items-center p-2 bg-muted/50 rounded-lg"
                    >
                      <span className="text-2xl mb-1">{badge.emoji}</span>
                      <span className="text-xs text-center">{badge.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Star className="h-4 w-4 text-yellow-500" />
                  Destaque da Semana
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm">
                  Você está no <strong>Top 5%</strong> em algoritmos de JavaScript!
                </p>
                <p className="text-xs text-muted-foreground">
                  Empresas estão procurando por desenvolvedores com seu perfil.
                </p>
                <Button className="w-full" variant="outline">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Ver Análise Completa
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Estatísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Visualizações do Perfil</span>
                  <strong className="text-sm">342</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Empresas Interessadas</span>
                  <strong className="text-sm">8</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Match Médio</span>
                  <strong className="text-sm">87%</strong>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
