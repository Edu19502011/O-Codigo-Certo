"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart3, TrendingUp, Award, Target, Calendar, Zap } from "lucide-react"
import { motion } from "framer-motion"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const activityData = [
  { name: "Seg", xp: 120 },
  { name: "Ter", xp: 180 },
  { name: "Qua", xp: 95 },
  { name: "Qui", xp: 220 },
  { name: "Sex", xp: 165 },
  { name: "Sáb", xp: 140 },
  { name: "Dom", xp: 90 },
]

const progressData = [
  { month: "Jan", completed: 4 },
  { month: "Fev", completed: 7 },
  { month: "Mar", completed: 5 },
  { month: "Abr", completed: 9 },
  { month: "Mai", completed: 11 },
  { month: "Jun", completed: 8 },
]

const skillsData = [
  { name: "JavaScript", value: 92, color: "#f7df1e" },
  { name: "TypeScript", value: 85, color: "#3178c6" },
  { name: "React", value: 88, color: "#61dafb" },
  { name: "Node.js", value: 78, color: "#339933" },
]

const COLORS = ["#6366f1", "#8b5cf6", "#ec4899", "#f59e0b"]

export default function PainelPage() {
  return (
    <div className="container py-8 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-4xl font-bold flex items-center gap-3">
          <BarChart3 className="h-10 w-10" />
          Meu Painel Analítico
        </h1>
        <p className="text-muted-foreground text-lg">
          Dashboard de Business Intelligence personalizado
        </p>
      </motion.div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[
          {
            title: "XP Total",
            value: "4,850",
            change: "+12%",
            icon: Zap,
            color: "text-yellow-500",
          },
          {
            title: "Sequência Atual",
            value: "12 dias",
            change: "Recorde pessoal!",
            icon: Calendar,
            color: "text-orange-500",
          },
          {
            title: "Desafios Completos",
            value: "48",
            change: "+8 esta semana",
            icon: Target,
            color: "text-green-500",
          },
          {
            title: "Ranking Global",
            value: "Top 5%",
            change: "↑ 2 posições",
            icon: Award,
            color: "text-purple-500",
          },
        ].map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + index * 0.05 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                  <Badge variant="secondary" className="text-xs">
                    {stat.change}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Atividade Semanal (XP)</CardTitle>
              <CardDescription>Pontos conquistados nos últimos 7 dias</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={activityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #334155",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="xp" fill="#6366f1" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Progresso Mensal</CardTitle>
              <CardDescription>Desafios completados por mês</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="month" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #334155",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="completed"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    dot={{ fill: "#8b5cf6", r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Mapa de Calor - Atividade</CardTitle>
              <CardDescription>Últimos 30 dias</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {Array.from({ length: 28 }, (_, i) => {
                  const intensity = Math.random()
                  return (
                    <div
                      key={i}
                      className="aspect-square rounded-sm transition-all hover:scale-110 cursor-pointer"
                      style={{
                        backgroundColor:
                          intensity > 0.7
                            ? "#6366f1"
                            : intensity > 0.4
                            ? "#818cf8"
                            : intensity > 0.2
                            ? "#a5b4fc"
                            : "#e0e7ff",
                      }}
                      title={`Dia ${i + 1}: ${Math.floor(intensity * 100)} XP`}
                    />
                  )
                })}
              </div>
              <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
                <span>Menos ativo</span>
                <div className="flex gap-1">
                  {[0, 0.25, 0.5, 0.75, 1].map((intensity, i) => (
                    <div
                      key={i}
                      className="w-4 h-4 rounded-sm"
                      style={{
                        backgroundColor:
                          intensity > 0.7
                            ? "#6366f1"
                            : intensity > 0.4
                            ? "#818cf8"
                            : intensity > 0.2
                            ? "#a5b4fc"
                            : "#e0e7ff",
                      }}
                    />
                  ))}
                </div>
                <span>Mais ativo</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Distribuição de Skills</CardTitle>
              <CardDescription>Nível de proficiência</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {skillsData.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-muted-foreground">{skill.value}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full transition-all"
                      style={{
                        width: `${skill.value}%`,
                        backgroundColor: skill.color,
                      }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card className="card-gradient border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Análise de IA - Pontos Fortes vs. Pontos Fracos
            </CardTitle>
            <CardDescription>Gerado pela inteligência artificial</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-green-500">✓ Pontos Fortes</h4>
                <ul className="space-y-2">
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-green-500">•</span>
                    <span>Excelente domínio de programação assíncrona (Promises, Async/Await)</span>
                  </li>
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-green-500">•</span>
                    <span>Alta consistência de estudos (12 dias de sequência)</span>
                  </li>
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-green-500">•</span>
                    <span>Bom desempenho em desafios de algoritmos</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3 text-orange-500">⚠ Áreas para Melhorar</h4>
                <ul className="space-y-2">
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-orange-500">•</span>
                    <span>Conceitos de closures e escopos precisam de reforço</span>
                  </li>
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-orange-500">•</span>
                    <span>Baixa participação em sessões de pair programming</span>
                  </li>
                  <li className="text-sm flex items-start gap-2">
                    <span className="text-orange-500">•</span>
                    <span>Design patterns: apenas 30% de progresso</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
