export default function RegistroLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
