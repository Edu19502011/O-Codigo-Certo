"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Code2, Mail, Lock, User, Github, Chrome, ArrowRight, Sparkles, Check } from "lucide-react"
import { useAuthStore } from "@/lib/store"

export default function RegistroPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)
  const { register } = useAuthStore()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      if (step === 1) {
        setStep(2)
        setIsLoading(false)
      } else {
        await register(formData.name, formData.email, formData.password)
        window.location.href = "/"
      }
    } catch (error) {
      console.error(error)
      setIsLoading(false)
    }
  }

  const passwordStrength = (password: string) => {
    let strength = 0
    if (password.length >= 8) strength++
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++
    if (/[0-9]/.test(password)) strength++
    if (/[^a-zA-Z0-9]/.test(password)) strength++
    return strength
  }

  const getStrengthColor = (strength: number) => {
    if (strength === 0) return "bg-red-500"
    if (strength === 1) return "bg-orange-500"
    if (strength === 2) return "bg-yellow-500"
    if (strength === 3) return "bg-lime-500"
    return "bg-green-500"
  }

  const strength = passwordStrength(formData.password)

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-background via-purple-500/5 to-pink-500/10">
      <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px]" />
      
      <div className="absolute top-10 right-10 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-pink-500/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "1.5s" }} />

      <div className="container relative z-10 flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-6xl grid md:grid-cols-2 gap-8 items-center"
        >
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="order-2 md:order-1"
          >
            <Card className="backdrop-blur-xl bg-card/80 border-primary/20 shadow-2xl">
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Sparkles className="h-6 w-6 text-primary" />
                  Comece sua jornada
                </CardTitle>
                <CardDescription>
                  Crie sua conta e transforme sua carreira em tech
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2 mb-6">
                  {[1, 2].map((s) => (
                    <div
                      key={s}
                      className={`h-2 flex-1 rounded-full transition-all ${
                        step >= s ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  ))}
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {step === 1 ? (
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-4"
                    >
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome Completo</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="name"
                            type="text"
                            placeholder="João Silva"
                            value={formData.name}
                            onChange={(e) =>
                              setFormData({ ...formData, name: e.target.value })
                            }
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="seu@email.com"
                            value={formData.email}
                            onChange={(e) =>
                              setFormData({ ...formData, email: e.target.value })
                            }
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>

                      <Button type="submit" className="w-full group" size="lg" disabled={isLoading}>
                        {isLoading ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          >
                            <Sparkles className="h-4 w-4" />
                          </motion.div>
                        ) : (
                          <>
                            Continuar
                            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          </>
                        )}
                      </Button>
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="space-y-4"
                    >
                      <div className="space-y-2">
                        <Label htmlFor="password">Senha</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="password"
                            type="password"
                            placeholder="••••••••"
                            value={formData.password}
                            onChange={(e) =>
                              setFormData({ ...formData, password: e.target.value })
                            }
                            className="pl-10"
                            required
                          />
                        </div>
                        {formData.password && (
                          <div className="space-y-2">
                            <div className="flex gap-1">
                              {[...Array(4)].map((_, i) => (
                                <div
                                  key={i}
                                  className={`h-1 flex-1 rounded-full transition-all ${
                                    i < strength ? getStrengthColor(strength) : "bg-muted"
                                  }`}
                                />
                              ))}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {strength === 0 && "Muito fraca"}
                              {strength === 1 && "Fraca"}
                              {strength === 2 && "Média"}
                              {strength === 3 && "Forte"}
                              {strength === 4 && "Muito forte"}
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="confirmPassword"
                            type="password"
                            placeholder="••••••••"
                            value={formData.confirmPassword}
                            onChange={(e) =>
                              setFormData({ ...formData, confirmPassword: e.target.value })
                            }
                            className="pl-10"
                            required
                          />
                          {formData.confirmPassword &&
                            formData.password === formData.confirmPassword && (
                              <Check className="absolute right-3 top-3 h-4 w-4 text-green-500" />
                            )}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setStep(1)}
                        >
                          Voltar
                        </Button>
                        <Button type="submit" className="flex-1 group" disabled={isLoading}>
                          {isLoading ? (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            >
                              <Sparkles className="h-4 w-4" />
                            </motion.div>
                          ) : (
                            <>
                              Criar Conta
                              <Sparkles className="ml-2 h-4 w-4" />
                            </>
                          )}
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </form>

                {step === 1 && (
                  <>
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-card px-2 text-muted-foreground">Ou registre-se com</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" type="button">
                        <Github className="mr-2 h-4 w-4" />
                        Github
                      </Button>
                      <Button variant="outline" type="button">
                        <Chrome className="mr-2 h-4 w-4" />
                        Google
                      </Button>
                    </div>
                  </>
                )}

                <div className="text-center text-sm">
                  Já tem uma conta?{" "}
                  <Link href="/login" className="text-primary font-semibold hover:underline">
                    Fazer login
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hidden md:block space-y-6 order-1 md:order-2"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
                <Code2 className="h-7 w-7 text-white" />
              </div>
              <span className="font-bold text-3xl text-gradient">O Código Certo</span>
            </div>

            <h1 className="text-5xl font-bold leading-tight">
              Junte-se a <span className="text-gradient">+10.000 devs</span> que já estão aprendendo
            </h1>

            <p className="text-xl text-muted-foreground">
              A plataforma mais completa para você dominar programação com IA, projetos reais e comunidade ativa.
            </p>

            <div className="space-y-4 pt-4">
              {[
                { icon: "🎓", title: "Aprenda do zero", text: "Trilhas completas para iniciantes" },
                { icon: "🚀", title: "Projetos reais", text: "Execute código e veja resultados instantâneos" },
                { icon: "🤝", title: "Comunidade", text: "Mentores e devs para te ajudar" },
                { icon: "💼", title: "Oportunidades", text: "Conecte-se com empresas contratando" },
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                  className="p-4 rounded-lg bg-card/50 backdrop-blur-sm border"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-3xl">{feature.icon}</span>
                    <div>
                      <h3 className="font-semibold mb-1">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.text}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}
