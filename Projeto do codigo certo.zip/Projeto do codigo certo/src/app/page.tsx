"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, Sparkles, Trophy, Flame, TrendingUp } from "lucide-react"
import { motion } from "framer-motion"

export default function Home() {
  return (
    <div className="container py-8 space-y-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-4xl font-bold">Bem-vindo de volta, Dev! 👋</h1>
        <p className="text-muted-foreground text-lg">
          Sua jornada de aprendizado personalizada continua aqui
        </p>
      </motion.div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="col-span-full md:col-span-2 card-gradient border-primary/20 hover-lift">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="flex items-center gap-2">
                    🎯 Continue Sua Trilha
                    <Badge className="ml-2 animate-pulse-glow">
                      <Sparkles className="h-3 w-3 mr-1" />
                      IA Sugerido
                    </Badge>
                  </CardTitle>
                  <CardDescription>
                    Você está indo muito bem! 3 módulos restantes
                  </CardDescription>
                </div>
                <div className="relative w-24 h-24">
                  <svg className="transform -rotate-90" width="96" height="96">
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      className="text-muted"
                    />
                    <circle
                      cx="48"
                      cy="48"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 40}`}
                      strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.7)}`}
                      className="text-primary"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl font-bold">70%</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-lg mb-2">JavaScript Avançado: Async/Await</h4>
                <Progress value={70} className="h-2" />
              </div>
              <Button className="w-full" size="lg">
                Continuar Aprendendo
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full border-orange-500/20 bg-gradient-to-br from-orange-500/5 to-red-500/5 hover-lift">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                ⚡ Desafio do Dia
                <Badge variant="destructive" className="ml-auto">Difícil</Badge>
              </CardTitle>
              <CardDescription>Personalizado pela IA</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Promise Chain Challenge</h4>
                <p className="text-sm text-muted-foreground">
                  Implemente uma cadeia de promises com tratamento de erros
                </p>
              </div>
              <div className="flex gap-4 text-sm">
                <span className="flex items-center gap-1">
                  <Trophy className="h-4 w-4 text-yellow-500" />
                  150 XP
                </span>
                <span className="text-muted-foreground">
                  👥 234 tentaram
                </span>
              </div>
              <Button variant="outline" className="w-full">
                Aceitar Desafio
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="hover-lift">
            <CardHeader>
              <CardTitle>💡 Recomendado para Você</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { icon: "📚", title: "Design Patterns em JS", subtitle: "Baseado no seu progresso" },
                { icon: "🎮", title: "Torneio de Algoritmos", subtitle: "Começa em 2 horas" },
                { icon: "👨‍🏫", title: "Mentor Carlos está online", subtitle: "Expert em Node.js" },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded-lg hover:bg-accent cursor-pointer transition-colors">
                  <span className="text-2xl">{item.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{item.title}</p>
                    <p className="text-xs text-muted-foreground">{item.subtitle}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20 hover-lift">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flame className="h-5 w-5 text-orange-500" />
                Sua Sequência
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-5xl font-bold text-orange-500">12</div>
                <p className="text-sm text-muted-foreground">dias consecutivos</p>
              </div>
              <div className="flex justify-center gap-2">
                {["S", "T", "Q", "Q", "S", "S", "D"].map((day, i) => (
                  <div
                    key={i}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                      i < 6
                        ? "bg-orange-500 text-white"
                        : "bg-orange-500/20 text-orange-500 ring-2 ring-orange-500"
                    }`}
                  >
                    {day}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="md:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Atividade Recente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  icon: "✓",
                  iconClass: "bg-green-500",
                  title: 'Concluiu: "Promises e Error Handling"',
                  time: "2 horas atrás",
                  xp: "+80 XP",
                },
                {
                  icon: "💬",
                  iconClass: "bg-blue-500",
                  title: 'Respondeu no fórum: "Como funciona o event loop?"',
                  time: "5 horas atrás",
                  xp: "+15 XP",
                },
                {
                  icon: "🏆",
                  iconClass: "bg-yellow-500",
                  title: 'Conquistou badge: "Promise Master"',
                  time: "Ontem",
                  xp: "+200 XP",
                },
              ].map((activity, i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-accent transition-colors">
                  <div className={`w-10 h-10 rounded-full ${activity.iconClass} flex items-center justify-center text-white font-bold`}>
                    {activity.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                  <Badge variant="secondary">{activity.xp}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>👥 Comunidade Ativa</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">1,234</div>
                  <p className="text-sm text-muted-foreground">Devs online agora</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-500">45</div>
                  <p className="text-sm text-muted-foreground">Sessões de pair programming</p>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                Explorar Comunidade
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
