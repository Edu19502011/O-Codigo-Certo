"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Play,
  Square,
  FileCode,
  Terminal,
  Trophy,
  Users,
  Clock,
  Check,
  X,
} from "lucide-react"
import { motion } from "framer-motion"
import dynamic from "next/dynamic"

const Editor = dynamic(() => import("@monaco-editor/react"), { ssr: false })

const challenges = [
  {
    id: 1,
    title: "Promise Chain Challenge",
    difficulty: "Difícil",
    xp: 150,
    participants: 234,
  },
  {
    id: 2,
    title: "Async Array Manipulation",
    difficulty: "Médio",
    xp: 100,
    participants: 567,
  },
  {
    id: 3,
    title: "Event Loop Quiz",
    difficulty: "Fácil",
    xp: 50,
    participants: 891,
  },
]

export default function LabPage() {
  const [code, setCode] = useState(`// Bem-vindo ao Lab de Código!
// Execute seu código em um ambiente seguro

async function fetchUserData() {
  try {
    const response = await fetch('https://api.example.com/users');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro:', error);
  }
}

fetchUserData();`)

  const [isRunning, setIsRunning] = useState(false)
  const [output, setOutput] = useState("")
  const [testResults, setTestResults] = useState<Array<{ name: string; passed: boolean }>>([])

  const handleRunCode = async () => {
    setIsRunning(true)
    setOutput("Executando código em container Docker...\n")

    setTimeout(() => {
      setOutput((prev) => prev + "✓ Container criado\n")
      setTimeout(() => {
        setOutput((prev) => prev + "✓ Código executado com sucesso\n")
        setOutput((prev) => prev + "\nSaída:\n{ users: [...] }\n")
        setTestResults([
          { name: "Deve fazer fetch de dados", passed: true },
          { name: "Deve tratar erros corretamente", passed: true },
          { name: "Deve retornar um array", passed: false },
        ])
        setIsRunning(false)
      }, 1500)
    }, 1000)
  }

  const handleStopExecution = () => {
    setIsRunning(false)
    setOutput((prev) => prev + "\n⚠️ Execução interrompida pelo usuário\n")
  }

  return (
    <div className="container py-8 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-4xl font-bold flex items-center gap-3">
          <FileCode className="h-10 w-10" />
          Lab de Código
        </h1>
        <p className="text-muted-foreground text-lg">
          Ambiente de desenvolvimento completo no navegador com execução segura
        </p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            >
            <Card className="hover-lift glow-effect">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCode className="h-5 w-5" />
                    <CardTitle className="text-lg">Editor de Código</CardTitle>
                    <Badge variant="outline" className="ml-2">
                      JavaScript
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    {!isRunning ? (
                      <Button size="sm" onClick={handleRunCode} className="gap-2">
                        <Play className="h-4 w-4" />
                        Executar
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={handleStopExecution}
                        className="gap-2"
                      >
                        <Square className="h-4 w-4" />
                        Parar
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="border rounded-lg overflow-hidden">
                  <Editor
                    height="400px"
                    defaultLanguage="javascript"
                    theme="vs-dark"
                    value={code}
                    onChange={(value) => setCode(value || "")}
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      lineNumbers: "on",
                      scrollBeyondLastLine: false,
                      automaticLayout: true,
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Terminal className="h-4 w-4" />
                    Terminal de Saída
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-black/90 text-green-400 p-4 rounded-lg font-mono text-sm h-48 overflow-auto">
                    <pre className="whitespace-pre-wrap">{output || "Aguardando execução..."}</pre>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    Resultados dos Testes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {testResults.length > 0 ? (
                    <div className="space-y-2">
                      {testResults.map((test, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 p-2 rounded-lg border"
                        >
                          {test.passed ? (
                            <Check className="h-4 w-4 text-green-500" />
                          ) : (
                            <X className="h-4 w-4 text-red-500" />
                          )}
                          <span className="text-sm">{test.name}</span>
                        </div>
                      ))}
                      <div className="pt-2 mt-2 border-t">
                        <p className="text-sm font-semibold">
                          Passou: {testResults.filter((t) => t.passed).length}/
                          {testResults.length} testes
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground h-48 flex items-center justify-center">
                      Execute o código para ver os resultados
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="card-gradient border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Torneios Ativos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Speed Coding Championship</span>
                    <Badge variant="destructive" className="animate-pulse">
                      Ao Vivo
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>Termina em 2h 15m</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Users className="h-3 w-3" />
                    <span>347 participantes</span>
                  </div>
                </div>
                <Button className="w-full" size="sm">
                  Participar Agora
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Desafios Recomendados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {challenges.map((challenge, i) => (
                  <div
                    key={challenge.id}
                    className="p-3 border rounded-lg hover:bg-accent cursor-pointer transition-colors"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm">{challenge.title}</h4>
                      <Badge
                        variant={
                          challenge.difficulty === "Difícil"
                            ? "destructive"
                            : challenge.difficulty === "Médio"
                            ? "default"
                            : "secondary"
                        }
                        className="text-xs"
                      >
                        {challenge.difficulty}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        {challenge.xp} XP
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {challenge.participants} tentaram
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Leaderboard Global</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { rank: 1, name: "CodeMaster99", score: 2850 },
                    { rank: 2, name: "DevNinja", score: 2720 },
                    { rank: 3, name: "JavaScriptPro", score: 2680 },
                    { rank: 42, name: "Você", score: 1450, isUser: true },
                  ].map((player) => (
                    <div
                      key={player.rank}
                      className={`flex items-center gap-3 p-2 rounded-lg ${
                        player.isUser ? "bg-primary/10 border border-primary/20" : "bg-muted/30"
                      }`}
                    >
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                        {player.rank}
                      </div>
                      <span className="flex-1 text-sm font-medium">{player.name}</span>
                      <span className="text-sm text-muted-foreground">{player.score}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
