"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Send,
  Phone,
  Video,
  ScreenShare,
  Users,
  Code2,
  MessageCircle,
  Search,
} from "lucide-react"
import { motion } from "framer-motion"
import { Avatar } from "@radix-ui/react-avatar"

const channels = [
  { id: 1, name: "# geral", unread: 3, active: true },
  { id: 2, name: "# javascript", unread: 0, active: false },
  { id: 3, name: "# pair-programming", unread: 12, active: false },
  { id: 4, name: "# dúvidas", unread: 5, active: false },
]

const onlineUsers = [
  { id: 1, name: "Carlos Mentor", status: "Mentoria", avatar: "👨‍🏫", color: "bg-green-500" },
  { id: 2, name: "Ana Silva", status: "No Lab", avatar: "👩‍💻", color: "bg-blue-500" },
  { id: 3, name: "Pedro Dev", status: "Online", avatar: "👨‍💼", color: "bg-green-500" },
  { id: 4, name: "Julia Code", status: "Pair Programming", avatar: "👩‍🔬", color: "bg-purple-500" },
]

const messages = [
  {
    id: 1,
    user: "Carlos Mentor",
    avatar: "👨‍🏫",
    message: "Alguém precisa de ajuda com async/await?",
    time: "10:30",
    reactions: ["👍", "🔥"],
  },
  {
    id: 2,
    user: "Você",
    avatar: "👤",
    message: "Sim! Estou com dúvida sobre promise chaining",
    time: "10:32",
    isUser: true,
  },
  {
    id: 3,
    user: "Ana Silva",
    avatar: "👩‍💻",
    message: "Também tenho interesse nesse tópico!",
    time: "10:33",
    reactions: ["👍"],
  },
  {
    id: 4,
    user: "Carlos Mentor",
    avatar: "👨‍🏫",
    message: "Vou abrir uma sessão de pair programming. Quem quer participar?",
    time: "10:35",
    reactions: ["🚀", "👏", "🎯"],
  },
]

export default function ConexoesPage() {
  const [messageInput, setMessageInput] = useState("")

  return (
    <div className="h-[calc(100vh-4rem)] flex">
      <div className="w-64 border-r bg-muted/20 flex flex-col">
        <div className="p-4 border-b">
          <h2 className="font-bold text-lg mb-4">Conexões</h2>
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar..."
              className="w-full pl-8 pr-3 py-2 text-sm rounded-md border bg-background"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-4">
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground mb-2">CANAIS</h3>
            <div className="space-y-1">
              {channels.map((channel) => (
                <div
                  key={channel.id}
                  className={`flex items-center justify-between px-2 py-1.5 rounded cursor-pointer hover:bg-accent ${
                    channel.active ? "bg-accent" : ""
                  }`}
                >
                  <span className="text-sm font-medium">{channel.name}</span>
                  {channel.unread > 0 && (
                    <Badge variant="destructive" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                      {channel.unread}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-muted-foreground mb-2">
              ONLINE ({onlineUsers.length})
            </h3>
            <div className="space-y-1">
              {onlineUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer hover:bg-accent"
                >
                  <div className="relative">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-lg">
                      {user.avatar}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-3 h-3 ${user.color} rounded-full border-2 border-background`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="h-16 border-b px-4 flex items-center justify-between bg-background">
          <div>
            <h2 className="font-bold"># geral</h2>
            <p className="text-xs text-muted-foreground">1,234 membros online</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Video className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <ScreenShare className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Users className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-4">
          {messages.map((msg, index) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`flex gap-3 ${msg.isUser ? "flex-row-reverse" : ""}`}
            >
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-xl flex-shrink-0">
                {msg.avatar}
              </div>
              <div className={`flex-1 ${msg.isUser ? "flex flex-col items-end" : ""}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-sm">{msg.user}</span>
                  <span className="text-xs text-muted-foreground">{msg.time}</span>
                </div>
                <div
                  className={`inline-block px-4 py-2 rounded-2xl ${
                    msg.isUser
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{msg.message}</p>
                </div>
                {msg.reactions && (
                  <div className="flex gap-1 mt-1">
                    {msg.reactions.map((reaction, i) => (
                      <div
                        key={i}
                        className="px-2 py-1 bg-accent rounded-full text-xs cursor-pointer hover:bg-accent/80"
                      >
                        {reaction}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="border-t p-4 bg-background">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Digite sua mensagem..."
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              className="flex-1 px-4 py-2 rounded-full border bg-background"
            />
            <Button size="icon" className="rounded-full">
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <Button variant="ghost" size="sm" className="text-xs">
              <Code2 className="h-3 w-3 mr-1" />
              Compartilhar Código
            </Button>
            <Button variant="ghost" size="sm" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              Iniciar Pair Programming
            </Button>
          </div>
        </div>
      </div>

      <div className="w-80 border-l bg-muted/20 p-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sessões Ativas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 border rounded-lg bg-green-500/10 border-green-500/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold">Pair Programming</span>
                <Badge className="bg-green-500 animate-pulse">Ao Vivo</Badge>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex -space-x-2">
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-xs border-2 border-background">
                    👨‍🏫
                  </div>
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-xs border-2 border-background">
                    👩‍💻
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">Carlos + Ana</span>
              </div>
              <Button size="sm" className="w-full" variant="outline">
                Participar
              </Button>
            </div>

            <div className="text-center py-8 text-muted-foreground">
              <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Nenhuma outra sessão ativa</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
