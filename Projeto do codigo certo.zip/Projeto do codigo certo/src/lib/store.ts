import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface User {
  id: string
  name: string
  email: string
  avatar?: string
  bio?: string
  birthDate?: string
  occupation?: string
  github?: string
  linkedin?: string
  twitter?: string
  level: number
  xp: number
  streak: number
}

interface AuthStore {
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
  updateProfile: (data: Partial<User>) => void
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        
        const user: User = {
          id: '1',
          name: 'João Developer',
          email,
          avatar: '👨‍💻',
          bio: 'Apaixonado por tecnologia e programação',
          occupation: 'Desenvolvedor Full Stack',
          level: 12,
          xp: 4850,
          streak: 12,
        }

        set({ user, isAuthenticated: true })
      },

      register: async (name: string, email: string, password: string) => {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        
        const user: User = {
          id: Date.now().toString(),
          name,
          email,
          avatar: '👤',
          level: 1,
          xp: 0,
          streak: 0,
        }

        set({ user, isAuthenticated: true })
      },

      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      updateProfile: (data: Partial<User>) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...data } : null,
        }))
      },
    }),
    {
      name: 'auth-storage',
    }
  )
)
