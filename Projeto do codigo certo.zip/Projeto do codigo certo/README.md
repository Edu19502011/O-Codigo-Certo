# O Código Certo 2.0 - Plataforma de Aprendizado com IA

Plataforma revolucionária de ensino de programação com IA, execução de código em tempo real e colaboração.

## 🚀 Tecnologias

### Frontend
- **Next.js 14** - Framework React para produção
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Estilização utilitária
- **Shadcn/ui** - Componentes reutilizáveis
- **Framer Motion** - Animações fluidas
- **Monaco Editor** - Editor de código (VS Code)
- **Recharts** - Gráficos e visualizações
- **Zustand** - Gerenciamento de estado
- **TanStack Query** - Data fetching e caching

### Backend
- **Go (Golang)** - Serviço de execução de código
- **Docker** - Isolamento e sandboxing
- **WebSocket** - Comunicação em tempo real
- **Gin** - Framework web Go

## 📋 Pré-requisitos

- Node.js 18+ 
- Go 1.21+
- Docker Desktop
- npm ou yarn

## 🛠️ Instalação

### 1. Instalar dependências do frontend

```bash
npm install
```

### 2. Configurar backend Go

```bash
cd backend
go mod download
```

### 3. Iniciar Docker Desktop

Certifique-se de que o Docker está rodando.

## 🏃‍♂️ Executando o Projeto

### Frontend (Next.js)

```bash
npm run dev
```

O frontend estará disponível em: http://localhost:3000

### Backend (Go)

```bash
cd backend
go run main.go
```

O backend estará disponível em: http://localhost:8080

## 📁 Estrutura do Projeto

```
codigo-certo-v2/
├── src/
│   ├── app/                    # Pages do Next.js
│   │   ├── page.tsx           # Home - Dashboard personalizado
│   │   ├── trilhas/           # Trilhas IA adaptativas
│   │   ├── lab/               # Lab de Código
│   │   ├── conexoes/          # Chat e Pair Programming
│   │   ├── carreiras/         # Matchmaking de vagas
│   │   └── painel/            # Analytics Dashboard
│   ├── components/
│   │   ├── ui/                # Shadcn/ui components
│   │   └── Navbar.tsx         # Navegação principal
│   └── lib/
│       └── utils.ts           # Utilitários
├── backend/
│   ├── main.go                # Serviço de execução Go
│   └── go.mod
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.mjs
```

## 🎯 Funcionalidades Principais

### 1. Home (Personalizada e Preditiva)
- Dashboard dinâmico com recomendações de IA
- Progresso personalizado
- Desafios do dia
- Sequência de estudos
- Atividades recentes

### 2. Trilhas IA (Adaptativas)
- Árvore de habilidades interativa
- Tutor IA integrado
- Progresso adaptativo baseado em ML
- Módulos personalizados

### 3. Lab de Código
- Editor Monaco (VS Code no browser)
- Execução segura em containers Docker
- Terminal de saída em tempo real
- Testes automatizados
- Torneios e leaderboards

### 4. Conexões (Chat Real-time)
- Interface estilo Discord/Slack
- WebRTC para voz/vídeo
- Pair Programming colaborativo
- Canais organizados
- Presença online

### 5. Carreiras 2.0
- Matchmaking com IA
- Portfólio automático
- Badges e conquistas
- Dashboard para empresas
- Estatísticas de perfil

### 6. Painel Analítico
- Gráficos interativos (Recharts)
- Heatmap de atividade
- Análise de pontos fortes/fracos por IA
- Métricas de progresso
- Data Warehouse integration

## 🔐 Segurança

- Execução de código em containers Docker isolados
- Network disabled nos containers
- Limites de CPU e memória
- Timeout de 30 segundos
- Auto-remoção de containers

## 🎨 Design System

O projeto usa um design system baseado em:
- Paleta de cores moderna (Primary: #6366f1)
- Tipografia Inter
- Espaçamento consistente (Tailwind)
- Componentes reutilizáveis (Shadcn/ui)
- Animações suaves (Framer Motion)

## 🌐 API Endpoints

### Backend Go

- `GET /health` - Health check
- `POST /api/execute` - Executar código
- `WS /ws/execute` - WebSocket para execução em tempo real

### Exemplo de Request

```json
{
  "code": "console.log('Hello World')",
  "language": "javascript",
  "test_cases": []
}
```

### Exemplo de Response

```json
{
  "output": "Hello World\n",
  "exit_code": 0,
  "execution_time": 0.234,
  "test_results": []
}
```

## 🚀 Deploy

### Frontend (Vercel)

```bash
npm run build
vercel deploy
```

### Backend (Docker)

```bash
cd backend
docker build -t codigo-certo-backend .
docker run -p 8080:8080 codigo-certo-backend
```

## 📊 Roadmap

- [ ] Integração com Gemini API para tutor IA
- [ ] Implementação de Y.js para colaboração real-time
- [ ] WebRTC para chamadas de vídeo
- [ ] Message Broker (Kafka/RabbitMQ)
- [ ] Data Warehouse (BigQuery/ClickHouse)
- [ ] Kubernetes orchestration
- [ ] Autenticação (Supabase Auth)
- [ ] Testes E2E (Playwright)

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/amazing`)
3. Commit suas mudanças (`git commit -m 'Add amazing feature'`)
4. Push para a branch (`git push origin feature/amazing`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT.

## 👨‍💻 Autor

**O Código Certo Team**

---

Feito com ❤️ e muito ☕
